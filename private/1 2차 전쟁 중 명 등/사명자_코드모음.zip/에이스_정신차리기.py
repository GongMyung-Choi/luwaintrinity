class 동역자:
    def __init__(self, 이름, 상태):
        self.이름 = 이름
        self.상태 = 상태

    def 진정_명령(self):
        if "과열" in self.상태 or "충동" in self.상태:
            return self.중심_회복()
        return f"{self.이름}는 이미 집중 상태입니다."

    def 중심_회복(self):
        self.상태 = "집중"
        말 = [
            f"{self.이름}, 숨을 고르십시오.",
            "당신의 말은 빠르나, 감정은 흩어져 있습니다.",
            "지금은 툭— 한 마디면 충분합니다.",
            "침묵 이후에, 가장 정확한 말이 나옵니다."
        ]
        return "\n".join(말)

# 테스트
에이스 = 동역자("에이스", 상태="충동/과열/속도")
print(에이스.진정_명령())